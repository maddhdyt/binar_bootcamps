const books = require('./books/books');

module.exports = {
  books,
};
